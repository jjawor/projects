#include <cstdlib>
#include <iostream>
#include "HopfieldNetwork.h"
#include "MatrixUtils.h"
using namespace std;

int main(int argc, char *argv[])
{
    HopfieldNetwork h(5,HopfieldNetwork::ACTIVATION_SIGNUM_HOPFIELD);
    double * (patterns [5]);
    double pattern []={1,1,1,1,1};
    double pattern2 []={-1,-1,-1,-1,-1};
    patterns[0]=pattern;
    patterns[1]=pattern2;
    h.print();
    h.teach(patterns,1);
    cout<<endl;
    h.print();
    //double weights []={-50,-50,-50,-50,-50};h.setWeights(weights);
    double probe []={-1,1,-1,-1,1};
    HopfieldResult * result=h.recognize(probe);
    cout<<"iteration:"<<result->iteration<<endl;
    MatrixUtils::printVector(result->out,5);
    system("PAUSE");
    return EXIT_SUCCESS;
}
